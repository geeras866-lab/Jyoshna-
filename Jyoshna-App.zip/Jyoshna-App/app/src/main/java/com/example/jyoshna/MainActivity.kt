package com.example.jyoshna

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.InputType
import android.view.Gravity
import android.view.WindowManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * Jyoshna - Gemini-style voice assistant.
 * Just talk. She waits while you keep speaking, understands what you want (WhatsApp, calls, apps,
 * YouTube, maps, alarms, web questions, movie-from-story) and answers by voice.
 */
class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var statusView: TextView
    private lateinit var talkBtn: Button
    private lateinit var langBtn: Button
    private lateinit var input: EditText

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private var handsFree = false
    private var speaking = false
    private var thinking = false
    private var teluguMode = false
    private var wakeOn = false
    private var awakeUntil = 0L
    private val history = ArrayList<Pair<String, String>>()

    // Patient listening: keep collecting what the user says until they pause for a while
    private val pending = StringBuilder()
    private val fire = Runnable { fireNow() }
    private val PAUSE_MS = 2500L

    private val wakeWords = listOf(
        "jyoshna", "joshna", "jyotsna", "jyothsna", "josna", "jyosna", "jyoshana",
        "జ్యోష్న", "జ్యోత్స్న", "జోష్న"
    )
    private val wakeRegex = Regex("\\b(jy?|y)o+(sh|s|th|ths|ts|tsh)n[a-z]{0,2}\\b", RegexOption.IGNORE_CASE)

    private val ROUTER_PROMPT = """
You are Jyoshna, a smart voice assistant on the user's Android phone, like Google Gemini. The user speaks English, Telugu or a mix. Understand the intent and answer ONLY with one JSON object, nothing else.

Fields:
"action": one of "chat","web","whatsapp","call","open_app","youtube","maps","search","alarm"
"reply": what you say aloud. Same language as the user (Telugu script if the user spoke Telugu). Natural and warm. One short sentence for phone actions, up to 4 sentences for chat.
"contact": the person's name in English letters (for whatsapp/call)
"message": the exact message text to send (for whatsapp), in the language the user dictated, written naturally
"number": digits only if the user dictated a phone number
"app": app name in English (for open_app)
"query": search text (for web, youtube, maps, search)
"hour","minute": 24-hour numbers (for alarm)

Rules:
- whatsapp: the user wants to message someone. Fill contact and message.
- call: phone call to a contact or number.
- web: anything needing fresh or factual info from the internet: news, scores, prices, weather, who/what is, identifying a movie, song or person from a description or story, reviews. Put the full question in query and leave reply empty.
- youtube: play or search videos or songs. maps: navigate or find places. search: open Google in the browser only when the user asks to open or browse a site.
- open_app: open an installed app.
- chat: casual talk, advice, jokes, explanations, translation, general knowledge that needs no fresh info.
- Use the earlier conversation to resolve words like "him", "that", "send it".
"""

    // ---------------------------------------------------------------- UI
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#060D16"))
            setPadding(dp(16), dp(40), dp(16), dp(16))
        }
        root.addView(TextView(this).apply {
            text = "⚡ JYOSHNA"; textSize = 26f; gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#19E6C1"))
        })
        statusView = TextView(this).apply {
            text = "Tap Start and just talk to me"
            setTextColor(Color.parseColor("#8AA2B8")); gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(10))
        }
        root.addView(statusView)

        logView = TextView(this).apply { textSize = 16f; setTextColor(Color.parseColor("#E6F3FF")) }
        scroll = ScrollView(this).apply { addView(logView) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        talkBtn = Button(this).apply { text = "🎤 Start Jyoshna"; setOnClickListener { toggle() } }
        langBtn = Button(this).apply {
            text = "English"
            setOnClickListener {
                teluguMode = !teluguMode
                text = if (teluguMode) "తెలుగు" else "English"
                if (handsFree) { stopListening(); startListening() }
            }
        }
        val wakeBtn = Button(this).apply {
            text = "Wake: OFF"
            setOnClickListener { wakeOn = !wakeOn; text = if (wakeOn) "Wake: ON" else "Wake: OFF" }
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(talkBtn, LinearLayout.LayoutParams(0, -2, 2f))
        row.addView(langBtn, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(wakeBtn, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row)

        input = EditText(this).apply {
            hint = "Or type a command…"
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, _, _ -> sendTyped(); true }
        }
        val sendBtn = Button(this).apply { text = "➤"; setOnClickListener { sendTyped() } }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        row2.addView(sendBtn)
        root.addView(row2)
        setContentView(root)

        tts = TextToSpeech(this, this)
        val need = ArrayList<String>()
        if (!has(Manifest.permission.RECORD_AUDIO)) need.add(Manifest.permission.RECORD_AUDIO)
        if (!has(Manifest.permission.READ_CONTACTS)) need.add(Manifest.permission.READ_CONTACTS)
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun status(t: String) { statusView.text = t }
    private fun addLog(who: String, t: String) {
        logView.append("$who: $t\n\n")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (has(Manifest.permission.RECORD_AUDIO)) status("Ready. Tap Start.")
        else status("Microphone permission is needed. Allow it in Settings > Apps > Jyoshna.")
    }

    private fun sendTyped() {
        val t = input.text.toString().trim()
        input.setText("")
        if (t.isNotEmpty()) process(t)
    }

    private fun toggle() {
        if (!has(Manifest.permission.RECORD_AUDIO)) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); return
        }
        handsFree = !handsFree
        if (handsFree) {
            talkBtn.text = "⏹ Stop"
            awakeUntil = System.currentTimeMillis() + 15000
            reply("Hi, I'm Jyoshna. I'm listening, just talk to me.")
        } else {
            talkBtn.text = "🎤 Start Jyoshna"
            ui.removeCallbacks(fire); pending.setLength(0)
            stopListening()
            status("Stopped")
        }
    }

    // ---------------------------------------------------------------- Speech out
    override fun onInit(s: Int) {
        ttsReady = s == TextToSpeech.SUCCESS
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { ui.post { speaking = false; afterSpeak() } }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { ui.post { speaking = false; afterSpeak() } }
        })
    }

    private fun speak(text: String) {
        if (!ttsReady) { afterSpeak(); return }
        val te = text.any { it in '\u0C00'..'\u0C7F' }
        val loc = if (te) Locale("te", "IN") else Locale("en", "IN")
        val t = tts!!
        if (t.isLanguageAvailable(loc) >= TextToSpeech.LANG_AVAILABLE) t.language = loc
        else {
            t.language = Locale.US
            if (te) status("Telugu voice isn't installed: Settings > Text-to-speech > install Telugu")
        }
        stopListening()
        speaking = true
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jyoshna")
    }

    private fun afterSpeak() {
        if (handsFree) ui.postDelayed({ startListening() }, 400)
    }

    private fun reply(text: String) {
        history.add("assistant" to text)
        addLog("Jyoshna", text)
        speak(text)
    }

    // ---------------------------------------------------------------- Speech in
    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(t: Int, p: Bundle?) {}
        override fun onPartialResults(p: Bundle?) {
            val t = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!t.isNullOrBlank()) {
                ui.removeCallbacks(fire)            // user is still talking: don't answer yet
                status("Hearing: $t")
            }
        }
        override fun onError(error: Int) {
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                status("Microphone permission is needed."); return
            }
            if (!handsFree) return
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    if (pending.isEmpty()) status("Listening… talk now")
                    ui.postDelayed({ startListening() }, 250)
                }
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> {
                    status("No internet for speech recognition. Retrying…")
                    ui.postDelayed({ startListening() }, 1500)
                }
                else -> {
                    status("Mic issue (code $error). Retrying…")
                    ui.postDelayed({ startListening() }, 1000)
                }
            }
        }
        override fun onResults(r: Bundle?) {
            val text = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
            onHeard(text)
        }
    }

    private fun startListening() {
        if (!handsFree || speaking || thinking) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status("Speech recognition isn't available on this phone"); return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (teluguMode) "te-IN" else "en-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
        }
        recognizer!!.startListening(i)
        if (pending.isEmpty()) status(if (!wakeOn || System.currentTimeMillis() < awakeUntil) "Listening… talk now" else "Say “Jyoshna …”")
    }

    private fun stopListening() {
        try { recognizer?.cancel() } catch (_: Exception) {}
    }

    private fun onHeard(text: String) {
        if (text.isBlank()) { startListening(); return }
        val low = text.lowercase()
        val hasWake = wakeWords.any { low.contains(it) } || wakeRegex.containsMatchIn(low)
        val now = System.currentTimeMillis()
        if (wakeOn && !hasWake && now > awakeUntil && pending.isEmpty()) {
            status("Heard: \"$text\" (say Jyoshna first)")
            ui.postDelayed({ startListening() }, 250); return
        }
        var cmd = text
        wakeWords.forEach { cmd = cmd.replace(it, "", ignoreCase = true) }
        cmd = wakeRegex.replace(cmd, "").trim(' ', ',', '.', '!', '?')
        awakeUntil = now + 20000
        if (cmd.isEmpty() && pending.isEmpty()) { reply("Yes, I'm listening."); return }
        if (cmd.isNotEmpty()) pending.append(if (pending.isEmpty()) "" else " ").append(cmd)
        status("Heard: $pending  (keep talking, I'm waiting…)")
        ui.removeCallbacks(fire)
        ui.postDelayed(fire, PAUSE_MS)                 // answer only after a real pause
        ui.postDelayed({ startListening() }, 150)      // keep listening for the rest of the sentence
    }

    private fun fireNow() {
        val full = pending.toString().trim()
        pending.setLength(0)
        if (full.isEmpty()) return
        stopListening()
        process(full)
    }

    // ---------------------------------------------------------------- Brain
    private fun process(cmd: String) {
        addLog("You", cmd)
        history.add("user" to cmd)
        askBrain()
    }

    private fun askBrain() {
        val prefs = getSharedPreferences("jyoshna", MODE_PRIVATE)
        val key = prefs.getString("groq", "") ?: ""
        if (key.isEmpty()) { askKey { askBrain() }; return }
        thinking = true
        status("Thinking…")
        val snap = history.takeLast(12).toList()
        Thread {
            val r = try { route(key, snap) } catch (e: Exception) {
                JSONObject().put("action", "error").put("reply", "Sorry, I couldn't reach the internet.")
            }
            ui.post { thinking = false; handleResult(key, r, snap) }
        }.start()
    }

    private fun handleResult(key: String, r: JSONObject, snap: List<Pair<String, String>>) {
        val say = r.optString("reply", "")
        when (r.optString("action")) {
            "badkey" -> reply("That API key was rejected. Please try again.")
            "whatsapp" -> doWhatsapp(r)
            "call" -> doCall(r)
            "open_app" -> reply(openApp(r.optString("app")))
            "youtube" -> {
                view("https://www.youtube.com/results?search_query=" + Uri.encode(r.optString("query")))
                reply(say.ifEmpty { "Opening YouTube." })
            }
            "maps" -> {
                launch(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(r.optString("query")))))
                reply(say.ifEmpty { "Opening maps." })
            }
            "search" -> {
                view("https://www.google.com/search?q=" + Uri.encode(r.optString("query")))
                reply(say.ifEmpty { "Here are the results." })
            }
            "alarm" -> {
                val i = Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, r.optInt("hour", 7))
                    .putExtra(AlarmClock.EXTRA_MINUTES, r.optInt("minute", 0))
                launch(i)
                reply(say.ifEmpty { "Setting your alarm." })
            }
            "web" -> webAnswer(key, r.optString("query").ifEmpty { snap.lastOrNull()?.second ?: "" })
            else -> reply(say.ifEmpty { "Sorry, I didn't get that." })
        }
    }

    private fun webAnswer(key: String, query: String) {
        thinking = true
        status("Searching the web…")
        Thread {
            val ans = try {
                val msgs = JSONArray()
                msgs.put(JSONObject().put("role", "system").put("content",
                    "You are Jyoshna, a voice assistant. Search the web and answer accurately and conversationally, in the same language as the user (Telugu script if the user used Telugu). " +
                    "If the user describes a movie's story, name the movie with its year and language, and say in one line why it matches. " +
                    "Maximum 5 sentences. Plain text, no markdown, no links."))
                msgs.put(JSONObject().put("role", "user").put("content", query))
                var out = ""
                for (m in listOf("groq/compound", "groq/compound-mini", "openai/gpt-oss-120b")) {
                    val (code, text) = call(key, m, msgs, false, 1024)
                    if (code in 200..299 && text.isNotEmpty()) { out = text; break }
                }
                if (out.isEmpty()) "Sorry, I couldn't get web results right now." else out
            } catch (e: Exception) { "Sorry, I couldn't reach the internet." }
            ui.post { thinking = false; reply(ans) }
        }.start()
    }

    private fun parseJson(s: String): JSONObject? {
        val a = s.indexOf('{'); val b = s.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        return try { JSONObject(s.substring(a, b + 1)) } catch (e: Exception) { null }
    }

    private fun route(key: String, snap: List<Pair<String, String>>): JSONObject {
        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content", ROUTER_PROMPT))
        snap.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
        var lastCode = 0
        for ((model, json) in listOf("openai/gpt-oss-20b" to true, "openai/gpt-oss-20b" to false, "openai/gpt-oss-120b" to false)) {
            val (code, out) = call(key, model, msgs, json, 1024)
            lastCode = code
            if (code == 401) return JSONObject().put("action", "badkey")
            if (code in 200..299 && out.isNotEmpty()) {
                return parseJson(out) ?: JSONObject().put("action", "chat").put("reply", out)
            }
        }
        return JSONObject().put("action", "error").put("reply", "Sorry, the AI service returned error $lastCode.")
    }

    private fun call(key: String, model: String, msgs: JSONArray, json: Boolean, maxTokens: Int): Pair<Int, String> {
        val body = JSONObject().put("model", model).put("messages", msgs).put("max_tokens", maxTokens)
        if (model.startsWith("openai/")) body.put("reasoning_effort", "low")
        if (json) body.put("response_format", JSONObject().put("type", "json_object"))
        val c = URL("https://api.groq.com/openai/v1/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 60000; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Authorization", "Bearer $key")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) return code to text
        val out = JSONObject(text).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").optString("content", "").trim()
        return code to out
    }

    private fun askKey(then: () -> Unit) {
        val et = EditText(this).apply { hint = "gsk_..."; inputType = InputType.TYPE_CLASS_TEXT }
        AlertDialog.Builder(this)
            .setTitle("Groq API key")
            .setMessage("Paste your Groq key once. It stays on this phone.")
            .setView(et)
            .setPositiveButton("Save") { _, _ ->
                val k = et.text.toString().trim()
                if (k.isNotEmpty()) { getSharedPreferences("jyoshna", MODE_PRIVATE).edit().putString("groq", k).apply(); then() }
            }
            .setNegativeButton("Cancel") { _, _ -> reply("I need a Groq key to understand you.") }
            .show()
    }

    // ---------------------------------------------------------------- Phone actions
    private fun launch(i: Intent): Boolean = try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); true } catch (e: Exception) { false }
    private fun view(url: String) = launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    private fun openApp(name: String): String {
        if (name.isBlank()) return "Which app should I open?"
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
        val n = name.lowercase().trim()
        val m = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == n }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }
        val intent = m?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        return if (m != null && intent != null && launch(intent)) "Opening ${m.loadLabel(pm)}."
        else "I couldn't find an app called $name."
    }

    private fun normalizePhone(raw: String): String {
        var d = raw.filter { it.isDigit() }
        if (d.length == 11 && d.startsWith("0")) d = d.substring(1)
        if (d.length == 10) d = "91$d"
        return d
    }

    private fun findContact(name: String): Pair<String, String>? {
        val words = name.trim().lowercase().split(" ").filter { it.isNotEmpty() }
        if (words.isEmpty() || !has(Manifest.permission.READ_CONTACTS)) return null
        val c = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        ) ?: return null
        var best: Pair<String, String>? = null
        var bestScore = 0
        c.use {
            while (it.moveToNext()) {
                val dn = it.getString(0) ?: continue
                val low = dn.lowercase()
                var score = 0
                if (low == name.trim().lowercase()) score = 100
                else {
                    words.forEach { w -> if (low.contains(w)) score += 10 }
                    if (low.startsWith(words[0])) score += 5
                }
                if (score > bestScore) { bestScore = score; best = dn to (it.getString(1) ?: "") }
            }
        }
        return if (bestScore >= 10) best else null
    }

    private fun resolveTarget(r: JSONObject): Pair<String, String>? {
        val contact = r.optString("contact")
        val num = r.optString("number")
        if (num.filter { it.isDigit() }.length >= 6) return (contact.ifEmpty { num }) to normalizePhone(num)
        if (contact.isEmpty()) { reply("Who do you mean?"); return null }
        if (!has(Manifest.permission.READ_CONTACTS)) {
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 2)
            reply("Please allow contacts permission, then ask me again."); return null
        }
        val f = findContact(contact)
        if (f == null || f.second.isEmpty()) { reply("I couldn't find $contact in your contacts."); return null }
        return f.first to normalizePhone(f.second)
    }

    private fun doWhatsapp(r: JSONObject) {
        val t = resolveTarget(r) ?: return
        val msg = r.optString("message")
        val url = "https://wa.me/${t.second}" + if (msg.isNotEmpty()) "?text=" + Uri.encode(msg) else ""
        reply(if (msg.isNotEmpty()) "Opening WhatsApp for ${t.first} with your message. Just tap send."
              else "Opening WhatsApp chat with ${t.first}.")
        ui.postDelayed({
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.whatsapp")
            if (!launch(i)) view(url)
        }, 1800)
    }

    private fun doCall(r: JSONObject) {
        val t = resolveTarget(r) ?: return
        reply("Calling ${t.first}.")
        ui.postDelayed({ launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:+" + t.second))) }, 1200)
    }

    override fun onDestroy() {
        handsFree = false
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
