package com.example.jyoshna

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.InputType
import android.view.Gravity
import android.view.WindowManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * Jyoshna - hands-free voice assistant.
 * Say "Jyoshna, <command>". After she answers, you can keep talking for 15 seconds without the name.
 */
class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var statusView: TextView
    private lateinit var talkBtn: Button
    private lateinit var langBtn: Button
    private lateinit var input: EditText

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private var handsFree = false
    private var speaking = false
    private var thinking = false
    private var teluguMode = false
    private var awakeUntil = 0L
    private val history = ArrayList<Pair<String, String>>()

    private val wakeWords = listOf(
        "jyoshna", "joshna", "jyotsna", "jyothsna", "josna", "jyosna", "jyoshana",
        "జ్యోష్న", "జ్యోత్స్న", "జోష్న"
    )

    // ---------------------------------------------------------------- UI
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#060D16"))
            setPadding(dp(16), dp(40), dp(16), dp(16))
        }
        root.addView(TextView(this).apply {
            text = "⚡ JYOSHNA"; textSize = 26f; gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#19E6C1"))
        })
        statusView = TextView(this).apply {
            text = "Tap Start, then say “Jyoshna, open YouTube”"
            setTextColor(Color.parseColor("#8AA2B8")); gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(10))
        }
        root.addView(statusView)

        logView = TextView(this).apply { textSize = 16f; setTextColor(Color.parseColor("#E6F3FF")) }
        scroll = ScrollView(this).apply { addView(logView) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        talkBtn = Button(this).apply { text = "🎤 Start Jyoshna"; setOnClickListener { toggle() } }
        langBtn = Button(this).apply {
            text = "English"
            setOnClickListener {
                teluguMode = !teluguMode
                text = if (teluguMode) "తెలుగు" else "English"
                if (handsFree) { stopListening(); startListening() }
            }
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(talkBtn, LinearLayout.LayoutParams(0, -2, 2f))
        row.addView(langBtn, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row)

        input = EditText(this).apply {
            hint = "Or type a command…"
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, _, _ -> sendTyped(); true }
        }
        val sendBtn = Button(this).apply { text = "➤"; setOnClickListener { sendTyped() } }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        row2.addView(sendBtn)
        root.addView(row2)
        setContentView(root)

        tts = TextToSpeech(this, this)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun status(t: String) { statusView.text = t }
    private fun addLog(who: String, t: String) {
        logView.append("$who: $t\n\n")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED) status("Mic ready. Tap Start.")
        else status("Microphone permission is needed. Allow it in Settings > Apps > Jyoshna.")
    }

    private fun sendTyped() {
        val t = input.text.toString().trim()
        input.setText("")
        if (t.isNotEmpty()) process(t)
    }

    private fun toggle() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); return
        }
        handsFree = !handsFree
        if (handsFree) {
            talkBtn.text = "⏹ Stop"
            awakeUntil = System.currentTimeMillis() + 15000
            reply("Hi, I'm Jyoshna. Say my name and give me a command.")
        } else {
            talkBtn.text = "🎤 Start Jyoshna"
            stopListening()
            status("Stopped")
        }
    }

    // ---------------------------------------------------------------- Speech out
    override fun onInit(s: Int) {
        ttsReady = s == TextToSpeech.SUCCESS
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { ui.post { speaking = false; afterSpeak() } }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { ui.post { speaking = false; afterSpeak() } }
        })
    }

    private fun speak(text: String) {
        if (!ttsReady) { afterSpeak(); return }
        val te = text.any { it in '\u0C00'..'\u0C7F' }
        val loc = if (te) Locale("te", "IN") else Locale("en", "IN")
        val t = tts!!
        t.language = if (t.isLanguageAvailable(loc) >= TextToSpeech.LANG_AVAILABLE) loc else Locale.US
        stopListening()
        speaking = true
        status("Speaking…")
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jyoshna")
    }

    private fun afterSpeak() {
        if (handsFree) ui.postDelayed({ startListening() }, 400)
    }

    private fun reply(text: String) {
        history.add("assistant" to text)
        addLog("Jyoshna", text)
        speak(text)
    }

    // ---------------------------------------------------------------- Speech in
    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(p: Bundle?) {}
        override fun onEvent(t: Int, p: Bundle?) {}
        override fun onError(error: Int) {
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                status("Microphone permission is needed."); return
            }
            if (handsFree) ui.postDelayed({ startListening() }, 700)
        }
        override fun onResults(r: Bundle?) {
            val text = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
            onHeard(text)
        }
    }

    private fun startListening() {
        if (!handsFree || speaking || thinking) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status("Speech recognition isn't available on this phone"); return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (teluguMode) "te-IN" else "en-IN")
        }
        recognizer!!.startListening(i)
        status(if (System.currentTimeMillis() < awakeUntil) "Listening…" else "Say “Jyoshna …”")
    }

    private fun stopListening() {
        try { recognizer?.cancel() } catch (_: Exception) {}
    }

    private fun onHeard(text: String) {
        if (text.isBlank()) { startListening(); return }
        val low = text.lowercase()
        val hasWake = wakeWords.any { low.contains(it) }
        val now = System.currentTimeMillis()
        if (!hasWake && now > awakeUntil) { startListening(); return }   // ignore chatter
        var cmd = text
        wakeWords.forEach { cmd = cmd.replace(it, "", ignoreCase = true) }
        cmd = cmd.trim(' ', ',', '.', '!', '?')
        awakeUntil = now + 15000
        if (cmd.isEmpty()) { reply("Yes, I'm listening."); return }
        process(cmd)
    }

    // ---------------------------------------------------------------- Commands
    private fun process(cmd: String) {
        addLog("You", cmd)
        history.add("user" to cmd)
        val local = tryAction(cmd)
        if (local != null) reply(local) else askBrain()
    }

    private fun launch(i: Intent): Boolean = try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); true } catch (e: Exception) { false }
    private fun view(url: String) = launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    private fun openApp(name: String): String {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
        val n = name.lowercase().trim()
        val m = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == n }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }
        val intent = m?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        return if (m != null && intent != null && launch(intent)) "Opening ${m.loadLabel(pm)}."
        else "I couldn't find an app called $name."
    }

    private fun tryAction(s: String): String? {
        val l = s.lowercase().trim().trimEnd('.', '!', '?')
        var m = Regex("^(?:play\\s+)?(.+?)\\s+on youtube$").find(l) ?: Regex("^play\\s+(.+)$").find(l)
        if (m != null) { view("https://www.youtube.com/results?search_query=" + Uri.encode(m.groupValues[1])); return "Playing ${m.groupValues[1]} on YouTube." }

        m = Regex("alarm (?:at|for)\\s+(\\d{1,2})(?::(\\d{2}))?\\s*(a\\.?m\\.?|p\\.?m\\.?)?").find(l)
        if (m != null) {
            var h = m.groupValues[1].toInt()
            val min = m.groupValues[2].ifEmpty { "0" }.toInt()
            val ap = m.groupValues[3]
            if (ap.startsWith("p") && h < 12) h += 12
            if (ap.startsWith("a") && h == 12) h = 0
            val i = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, min)
            return if (launch(i)) "Setting an alarm for %d:%02d.".format(h, min) else "I couldn't open the clock app."
        }

        m = Regex("^call\\s+(\\+?[\\d ]{6,})$").find(l)
        if (m != null) { launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + m.groupValues[1].replace(" ", "")))); return "Dialing ${m.groupValues[1]}." }

        m = Regex("^(?:navigate to|directions to|map of|where is)\\s+(.+)$").find(l)
        if (m != null) { launch(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(m.groupValues[1])))); return "Opening maps for ${m.groupValues[1]}." }

        if (l.startsWith("whatsapp") || l.startsWith("open whatsapp") || l.startsWith("send whatsapp")) {
            val n = Regex("\\+?\\d[\\d ]{8,}").find(l)
            if (n != null) { view("https://wa.me/" + n.value.filter { it.isDigit() }); return "Opening WhatsApp chat." }
            return openApp("whatsapp")
        }

        m = Regex("^(?:google|search for|search)\\s+(.+)$").find(l)
        if (m != null) { view("https://www.google.com/search?q=" + Uri.encode(m.groupValues[1])); return "Searching for ${m.groupValues[1]}." }

        m = Regex("^(?:open|launch|start)\\s+(.+)$").find(l)
        if (m != null) return openApp(m.groupValues[1])

        return null
    }

    // ---------------------------------------------------------------- AI brain (Groq)
    private fun askBrain() {
        val prefs = getSharedPreferences("jyoshna", MODE_PRIVATE)
        val key = prefs.getString("groq", "") ?: ""
        if (key.isEmpty()) { askKey { askBrain() }; return }
        thinking = true
        status("Thinking…")
        val snap = history.takeLast(10).toList()
        Thread {
            val ans = try { callGroq(key, snap) } catch (e: Exception) { "Sorry, I couldn't reach the internet." }
            ui.post { thinking = false; reply(ans) }
        }.start()
    }

    private fun askKey(then: () -> Unit) {
        val et = EditText(this).apply { hint = "gsk_..." ; inputType = InputType.TYPE_CLASS_TEXT }
        AlertDialog.Builder(this)
            .setTitle("Groq API key")
            .setMessage("Paste your Groq key once. It stays on this phone.")
            .setView(et)
            .setPositiveButton("Save") { _, _ ->
                val k = et.text.toString().trim()
                if (k.isNotEmpty()) { getSharedPreferences("jyoshna", MODE_PRIVATE).edit().putString("groq", k).apply(); then() }
            }
            .setNegativeButton("Cancel") { _, _ -> reply("I need a Groq key to chat. Phone commands still work.") }
            .show()
    }

    private fun callGroq(key: String, snap: List<Pair<String, String>>): String {
        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content",
            "You are Jyoshna, a fast, friendly personal AI assistant on the user's phone. " +
            "Reply in 1-2 short sentences, in the same language the user used (Telugu script if they spoke Telugu). Plain text only, no markdown."))
        snap.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
        val body = JSONObject().put("model", "llama-3.3-70b-versatile").put("messages", msgs).put("max_tokens", 200)

        val c = URL("https://api.groq.com/openai/v1/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 30000; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Authorization", "Bearer $key")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        if (code == 401) {
            getSharedPreferences("jyoshna", MODE_PRIVATE).edit().remove("groq").apply()
            return "That API key was rejected. Please try again."
        }
        if (code !in 200..299) return "Sorry, the AI service returned error $code."
        val text = c.inputStream.bufferedReader().use { it.readText() }
        return JSONObject(text).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content").trim()
    }

    override fun onDestroy() {
        handsFree = false
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
