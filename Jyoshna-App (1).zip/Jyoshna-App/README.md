# Jyoshna - Android voice assistant
Upload this whole folder to a GitHub repo. Then open the Actions tab, run "Build APK", and download Jyoshna-APK.
